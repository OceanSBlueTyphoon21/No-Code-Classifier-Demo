# Hey Pi: wake-word LED on a Raspberry Pi 4B

Listens through a USB microphone (tested with a Blue Yeti) for a wake word using a
[Teachable Machine](https://teachablemachine.withgoogle.com/) audio model. When the wake
word is detected, the Pi's on-board green LED turns on for 5 seconds, then off. Press **q**
to quit.

## How it works
- `web/index.html`: runs in Chromium, feeds mic audio to the Teachable Machine
  (TensorFlow.js speech-commands) model, and notifies the server when the wake word scores
  above the threshold.
- `server.py`: tiny Python web server. Serves `web/` and controls the ACT LED
  (`/sys/class/leds/ACT`; needs `sudo`). `POST /trigger` lights it for 5 s; `POST /quit` stops.
- `start.sh`: starts the server and opens Chromium; cleans up on quit.
- `setup.sh`: one-time download of the TensorFlow.js libraries into `web/lib/`.

## Setup (once, on the Pi)
1. `sudo apt update && sudo apt install -y chromium-browser pulseaudio-utils`
   (use `chromium` if `chromium-browser` isn't found).
2. Export your model from Teachable Machine: **Export Model -> TensorFlow.js -> Download**.
   Put `model.json`, `metadata.json` and `weights.bin` in `web/model/`.
3. In `web/index.html`, set `TRIGGER_LABEL` to your wake-word class name (exact match).
4. `chmod +x setup.sh start.sh server.py && ./setup.sh`
   (if files came from Windows: `sed -i 's/\r$//' setup.sh start.sh server.py`).

## Run
1. Make the microphone the default input:
   ```
   pactl list short sources
   pactl set-default-source <yeti-source-name>
   ```
2. From the Pi's desktop: `./start.sh` (enter your password; click **Allow** for the mic the first time).
3. Say the wake word. Press **q** to quit.

## Settings (`web/index.html`)
- `TRIGGER_LABEL`: wake-word class name
- `TRIGGER_THRESHOLD`: confidence needed (default 0.90; lower if it misses, raise if false alarms)
- `REQUIRED_HITS`: consecutive detections needed (default 1)

`server.py`: `LED_ON_SECONDS` (default 5), `PORT` (default 8000).

## Troubleshooting
- **"Unsupported URL scheme in metadata URL"**: `MODEL_URL` must be a full URL
  (`window.location.origin + "/model/"`), already set here.
- **Class not found**: the page lists the model's class names; copy yours into `TRIGGER_LABEL`.
- **No detections**: watch the on-screen scores; check `pactl get-default-source`; record more samples.
- **LED test**: `sudo sh -c 'echo none > /sys/class/leds/ACT/trigger; echo 1 > /sys/class/leds/ACT/brightness'`
