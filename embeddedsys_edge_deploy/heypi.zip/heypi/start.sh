#!/bin/bash
# Run as your normal user, from the Pi's desktop session (not over plain SSH).
cd "$(dirname "$0")"

# Ask for the sudo password up front so the background server doesn't prompt
# behind the browser window. (sudo is needed to control the on-board LED.)
sudo -v

sudo python3 server.py < /dev/null &
SERVER_PID=$!
sleep 2

BROWSER=$(command -v chromium-browser || command -v chromium)
"$BROWSER" --app=http://localhost:8000 \
  --user-data-dir="$HOME/.heypi-chromium" \
  --password-store=basic \
  --autoplay-policy=no-user-gesture-required \
  --no-first-run --disable-session-crashed-bubble &

# Wait until the server exits (q pressed), then close the browser window.
while kill -0 "$SERVER_PID" 2>/dev/null; do sleep 1; done
pkill -f heypi-chromium 2>/dev/null
echo "Stopped."
