#!/bin/bash
# One-time setup on the Pi (needs internet). Run as your normal user, not root.
set -e
cd "$(dirname "$0")"
mkdir -p web/lib web/model
curl -L -o web/lib/tf.min.js https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@1.3.1/dist/tf.min.js
curl -L -o web/lib/speech-commands.min.js https://cdn.jsdelivr.net/npm/@tensorflow-models/speech-commands@0.4.0/dist/speech-commands.min.js
chmod +x start.sh server.py
echo "Done. Now copy model.json, metadata.json and weights.bin into web/model/ and run ./start.sh"
