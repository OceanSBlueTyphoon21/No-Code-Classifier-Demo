#!/usr/bin/env python3
"""
Hey Pi - Raspberry Pi 4B LED controller.

Serves the wake-word web page (web/) and exposes two tiny endpoints:
  POST /trigger  -> turn the on-board ACT LED on for LED_ON_SECONDS, then off
  POST /quit     -> restore the LED and stop the server
Pressing "q" in this terminal (when run in the foreground) also quits.

Needs root to write to /sys/class/leds, so run with:  sudo python3 server.py
"""
import functools
import os
import select
import sys
import threading
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

PORT = 8000
LED_ON_SECONDS = 5
WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
LED_CANDIDATES = [os.environ.get("LED_DIR"), "/sys/class/leds/ACT", "/sys/class/leds/led0"]


class Led:
    def __init__(self):
        self.dir = next((p for p in LED_CANDIDATES if p and os.path.isdir(p)), None)
        if not self.dir:
            sys.exit("Could not find the on-board LED in /sys/class/leds (looked for ACT and led0).")
        self.lock = threading.Lock()
        self.timer = None
        self.is_on = False
        self.original_trigger = self._current_trigger()
        self._write("trigger", "none")  # take manual control (stops SD-card activity blinking)
        self._write("brightness", "0")

    def _write(self, name, value):
        with open(os.path.join(self.dir, name), "w") as f:
            f.write(value)

    def _current_trigger(self):
        try:
            with open(os.path.join(self.dir, "trigger")) as f:
                for tok in f.read().split():
                    if tok.startswith("[") and tok.endswith("]"):
                        return tok[1:-1]
        except OSError:
            pass
        return "mmc0"

    def trigger(self):
        """Turn LED on for LED_ON_SECONDS. Ignored if it is already on."""
        with self.lock:
            if self.is_on:
                return False
            self._write("brightness", "1")
            self.is_on = True
            self.timer = threading.Timer(LED_ON_SECONDS, self.off)
            self.timer.daemon = True
            self.timer.start()
            return True

    def off(self):
        with self.lock:
            self._write("brightness", "0")
            self.is_on = False

    def cleanup(self):
        if self.timer:
            self.timer.cancel()
        try:
            self._write("brightness", "0")
            self._write("trigger", self.original_trigger)  # give the LED back to the system
        except OSError:
            pass


led = Led()
httpd = None


def shutdown():
    threading.Thread(target=lambda: httpd.shutdown(), daemon=True).start()


class Handler(SimpleHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # keep the terminal clean

    def _reply(self, body=b"{}"):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        if self.path == "/trigger":
            fired = led.trigger()
            if fired:
                print("Wake word detected -> LED ON for %d s" % LED_ON_SECONDS, flush=True)
            self._reply(b'{"fired": %s}' % (b"true" if fired else b"false"))
        elif self.path == "/quit":
            self._reply()
            print("Quit requested from page.", flush=True)
            shutdown()
        else:
            self.send_error(404)

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()


def terminal_q_listener():
    """If run in a real terminal, quit when 'q' is typed there."""
    if not sys.stdin.isatty():
        return
    import termios
    import tty
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        while True:
            if select.select([sys.stdin], [], [], 0.5)[0]:
                if sys.stdin.read(1).lower() == "q":
                    print("q pressed in terminal.", flush=True)
                    shutdown()
                    return
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def main():
    global httpd
    handler = functools.partial(Handler, directory=WEB_DIR)
    httpd = ThreadingHTTPServer(("127.0.0.1", PORT), handler)
    threading.Thread(target=terminal_q_listener, daemon=True).start()
    print("Serving on http://localhost:%d  (LED: %s). Press q to quit." % (PORT, led.dir), flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        led.cleanup()
        httpd.server_close()
        print("Stopped. LED restored.", flush=True)


if __name__ == "__main__":
    main()
